package model.utility;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

/**
 * Calendar utility used to perform utility methods on calendar, period of time such as
 * get all working days for a period of time.
 */
public class CalendarUtility {

  /**
   * Returns equally spaced dates from the start and end range of the period.
   *
   * @param from the start date of the time range.
   * @param to   the end date of the time range.
   * @return the equally spaced periods of time i.e. monthly, daily, weekly, etc.
   */
  public static List<LocalDate> getWorkingDays(LocalDate from, LocalDate to) {
    if (ChronoUnit.DAYS.between(from, to) <= 30
            && ChronoUnit.DAYS.between(from, to) >= 5) {
      return initialize(CalendarScale.DAYS, from, to);
    } else if (ChronoUnit.WEEKS.between(from, to) <= 30
            && ChronoUnit.WEEKS.between(from, to) >= 5) {
      return initialize(CalendarScale.WEEKS, from, to);
    } else if (ChronoUnit.MONTHS.between(from, to) <= 30
            && ChronoUnit.MONTHS.between(from, to) >= 5) {
      return initialize(CalendarScale.MONTHS, from, to);
    } else if (ChronoUnit.YEARS.between(from, to) * 4 <= 30
            && ChronoUnit.YEARS.between(from, to) * 4 >= 5) {
      return initialize(CalendarScale.QUARTERLY, from, to);
    } else if (ChronoUnit.YEARS.between(from, to) <= 30
            && ChronoUnit.YEARS.between(from, to) >= 5) {
      return initialize(CalendarScale.YEARLY, from, to);
    }
    return null;
  }

  /**
   * Initialize the set of dates in equally spaced interval.
   *
   * @param type the type of the scale.
   * @param from the start date of the period.
   * @param to   the end date of the period.
   * @return the list of dates using the scale from start date to end.
   */
  private static List<LocalDate> initialize(CalendarScale type, LocalDate from, LocalDate to) {
    List<LocalDate> dates = new ArrayList<>();
    if (type != CalendarScale.DAYS) {
      from = getLastWorkingDay(type, from);
    }
    for (LocalDate date = from; date.isBefore(to); ) {
      dates.add(date);
      if (type == CalendarScale.DAYS) {
        date = date.plusDays(1);
      } else if (type == CalendarScale.WEEKS) {
        date = date.plusDays(7);
      } else if (type == CalendarScale.MONTHS) {
        date = date.plusMonths(1);
      } else if (type == CalendarScale.QUARTERLY) {
        date = date.plusMonths(3);
      } else if (type == CalendarScale.YEARLY) {
        date = date.plusYears(7);
      }
      if (type != CalendarScale.DAYS) {
        date = getLastWorkingDay(type, date);
      }
    }
    return dates;
  }

  /**
   * Returns the last working day for the given date according to the scale.
   *
   * @param type the scale i.e. weekly, quarterly, monthly etc.
   * @param date the date for while the last working day needs to be determined.
   * @return the last working day for the specified date and scale.
   */
  private static LocalDate getLastWorkingDay(CalendarScale type, LocalDate date) {
    LocalDate lastDate = date;
    if (type == CalendarScale.MONTHS || type == CalendarScale.YEARLY) {
      lastDate = getLastWorkingDayForMonthAndYear(type, date);
    } else if (type == CalendarScale.WEEKS) {
      lastDate = getLastWorkingDayForWeek(date);
    }
    return lastDate;
  }

  /**
   * Returns the last working day for the given date for a month or a year.
   *
   * @param type the scale i.e. monthly or yearly.
   * @param date the date for while the last working day needs to be determined.
   * @return the last working day for the month/year for the specified date.
   */
  private static LocalDate getLastWorkingDayForMonthAndYear(CalendarScale type, LocalDate date) {

    LocalDate lastDate = type == CalendarScale.YEARLY ?
            date.with(TemporalAdjusters.lastDayOfYear()) :
            date.with(TemporalAdjusters.lastDayOfMonth());
    while (!isWorkingDay(lastDate)) {
      lastDate = lastDate.minusDays(1);
    }
    return lastDate;
  }

  /**
   * Returns the last working day for the week.
   *
   * @param date the date for while the last working day needs to be determined.
   * @return the last working day for the week for the specified date.
   */
  private static LocalDate getLastWorkingDayForWeek(LocalDate date) {
    while (!isFriday(date)) {
      date = date.plusDays(1);
    }
    return date;
  }

  /**
   * Checks if the date is on a working day.
   *
   * @param date the date which needs to be determined.
   * @return if the date falls on a working day
   */
  private static boolean isWorkingDay(LocalDate date) {
    DayOfWeek day = date.getDayOfWeek();
    return day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY;
  }

  /**
   * Checks if the date falls on the Friday.
   *
   * @param date the date which needs to be determined.
   * @return if the date falls on the friday
   */
  private static boolean isFriday(LocalDate date) {
    DayOfWeek day = date.getDayOfWeek();
    return day == DayOfWeek.FRIDAY;
  }
}
