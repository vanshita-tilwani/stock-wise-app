package model.utility;

/**
 * Calendar used to determine the period to analyze the
 * time period.
 */
public enum CalendarScale {

  DAYS,
  WEEKS,
  MONTHS,
  QUARTERLY,
  YEARLY
}
